# Why is This Important?
This is important because this is one of the first function IXL Bot there is.


# What can it do

it can:
scrape questions and answers 
generate teacher accounts
inflate your time! (get over 10 hours w/o doing anything)
auto answer!

# How Does it Work?
Works by using an automation tool called Selenium, python.

# How do I download it?

first of all make sure you have python 3 installed, if you dont google how to download it.

Start of by going onto https://sites.google.com/a/chromium.org/chromedriver/downloads
Download Chromedriver depending on your chrome version.
Next download the file, next edit it with any text editor. 
now go the PATH variable or line 16. now find the directory for your webdriver and edit there. 

next open up cmd prompt and do pip install selenium.
next you will need to do this but with these:
pip install colorama
pip install Faker

i believe that is all.

# Is this a Virus?
No this is not a virus. IT is open source so you can check the code. 

# What works?
Still in development but only option 1 and 2 work. 
i have 3 done, you can try running it but you will get errors, i am still ficing that part of the code.
Same with the scraper, it only works with some questions until i add new Xpaths but i am too tired to do it today, so it expect it in a couple days.

# INFO
this code uses over 300 lines of code and was coded in all one day, so please expect some errors along the way.
If you want to report errors, DM on reddit or on IG, or if you  know python yourself, leave a pull request.

<a><img src="https://i.ibb.co/yN0x0TG/square-og-ixl.png" alt="square-og-ixl" border="0"></a>

